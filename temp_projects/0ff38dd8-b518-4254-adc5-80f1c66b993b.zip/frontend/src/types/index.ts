[
  "interface Patient {"
]