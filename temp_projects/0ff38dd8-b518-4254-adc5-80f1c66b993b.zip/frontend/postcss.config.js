{
  "plugins": {
    "tailwindcss": {},
    "autoprefixer": {}
  }
}