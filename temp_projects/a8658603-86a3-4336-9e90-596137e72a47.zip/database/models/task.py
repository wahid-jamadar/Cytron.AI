
from sqlalchemy import Column, Integer, String, ForeignKey
from sqlalchemy.orm import relationship
from models.base import Base, BaseMixin

class Task(Base, BaseMixin):
    __tablename__ = 'tasks'
    id = Column(Integer, primary_key=True)
    name = Column(String, nullable=False)
    description = Column(String, nullable=True)
    project_id = Column(Integer, ForeignKey('projects.id'), nullable=False)
    project = relationship('Project', back_populates='tasks')
    ai_agent_id = Column(Integer, ForeignKey('ai_agents.id'), nullable=True)
    ai_agent = relationship('AI_Agent', back_populates='tasks')