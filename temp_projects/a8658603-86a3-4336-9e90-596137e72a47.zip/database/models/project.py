
from sqlalchemy import Column, Integer, String, ForeignKey
from sqlalchemy.orm import relationship
from models.base import Base, BaseMixin

class Project(Base, BaseMixin):
    __tablename__ = 'projects'
    id = Column(Integer, primary_key=True)
    name = Column(String, nullable=False)
    description = Column(String, nullable=True)
    tasks = relationship('Task', back_populates='project')
    files = relationship('File', back_populates='project')
    codes = relationship('Code', back_populates='project')