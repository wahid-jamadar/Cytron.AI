
from sqlalchemy import Column, Integer, String
from sqlalchemy.orm import relationship
from models.base import Base, BaseMixin

class AI_Agent(Base, BaseMixin):
    __tablename__ = 'ai_agents'
    id = Column(Integer, primary_key=True)
    name = Column(String, nullable=False)
    description = Column(String, nullable=True)
    tasks = relationship('Task', back_populates='ai_agent')