
from sqlalchemy import Column, Integer, String, ForeignKey
from sqlalchemy.orm import relationship
from models.base import Base, BaseMixin

class User(Base, BaseMixin):
    __tablename__ = 'users'
    id = Column(Integer, primary_key=True)
    name = Column(String, nullable=False)
    email = Column(String, nullable=False)
    organization_id = Column(Integer, ForeignKey('organizations.id'), nullable=True)
    organization = relationship('Organization', back_populates='users')
    role_id = Column(Integer, ForeignKey('roles.id'), nullable=True)
    role = relationship('Role', back_populates='users')