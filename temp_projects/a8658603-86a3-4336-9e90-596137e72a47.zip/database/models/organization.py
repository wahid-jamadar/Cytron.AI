
from sqlalchemy import Column, Integer, String
from sqlalchemy.orm import relationship
from models.base import Base, BaseMixin

class Organization(Base, BaseMixin):
    __tablename__ = 'organizations'
    id = Column(Integer, primary_key=True)
    name = Column(String, nullable=False)
    description = Column(String, nullable=True)
    users = relationship('User', back_populates='organization')