
from models.project import Project
from models.task import Task
from models.ai_agent import AI_Agent
from models.file import File
from models.code import Code
from models.organization import Organization
from models.user import User
from models.role import Role
from database import get_db

def seed_data():
    db = next(get_db())
    project = Project(name='Project 1', description='This is project 1')
    db.add(project)
    db.commit()
    task = Task(name='Task 1', description='This is task 1', project_id=project.id)
    db.add(task)
    db.commit()
    ai_agent = AI_Agent(name='AI Agent 1', description='This is ai agent 1')
    db.add(ai_agent)
    db.commit()
    file = File(name='File 1', description='This is file 1', project_id=project.id)
    db.add(file)
    db.commit()
    code = Code(name='Code 1', description='This is code 1', project_id=project.id)
    db.add(code)
    db.commit()
    organization = Organization(name='Organization 1', description='This is organization 1')
    db.add(organization)
    db.commit()
    user = User(name='User 1', email='user1@example.com', organization_id=organization.id)
    db.add(user)
    db.commit()
    role = Role(name='Role 1', description='This is role 1')
    db.add(role)
    db.commit()