import { html, LitElement } from 'lit';
import { ProjectList } from '../components/ProjectList.tsx';
import { TaskList } from '../components/TaskList.tsx';
@LitElement()
class Dashboard extends LitElement {
  render() {
    return html`<h1>Dashboard</h1><${ProjectList} /><${TaskList} />`;
  }
}
export { Dashboard };