import { html, LitElement } from 'lit';
import { ChatWindow } from '../components/ChatWindow.tsx';
@LitElement()
class ChatSystem extends LitElement {
  render() {
    return html`<h1>Chat System</h1><${ChatWindow} />`;
  }
}
export { ChatSystem };