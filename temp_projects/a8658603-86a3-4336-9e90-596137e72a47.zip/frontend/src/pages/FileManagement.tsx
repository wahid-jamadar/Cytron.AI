import { html, LitElement } from 'lit';
import { FileList } from '../components/FileList.tsx';
import { FileUpload } from '../components/FileUpload.tsx';
@LitElement()
class FileManagement extends LitElement {
  render() {
    return html`<h1>File Management</h1><${FileList} /><${FileUpload} />`;
  }
}
export { FileManagement };