import { html, LitElement } from 'lit';
import { CodeEditor } from '../components/CodeEditor.tsx';
@LitElement()
class CodeGeneration extends LitElement {
  render() {
    return html`<h1>Code Generation</h1><${CodeEditor} />`;
  }
}
export { CodeGeneration };