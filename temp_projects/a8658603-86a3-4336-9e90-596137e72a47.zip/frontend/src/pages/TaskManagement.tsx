import { html, LitElement } from 'lit';
import { TaskList } from '../components/TaskList.tsx';
import { TaskForm } from '../components/TaskForm.tsx';
@LitElement()
class TaskManagement extends LitElement {
  render() {
    return html`<h1>Task Management</h1><${TaskList} /><${TaskForm} />`;
  }
}
export { TaskManagement };