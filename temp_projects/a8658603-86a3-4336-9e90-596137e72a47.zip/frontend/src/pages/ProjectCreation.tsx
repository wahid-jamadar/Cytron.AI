import { html, LitElement } from 'lit';
import { ProjectForm } from '../components/ProjectForm.tsx';
@LitElement()
class ProjectCreation extends LitElement {
  render() {
    return html`<h1>Project Creation</h1><${ProjectForm} />`;
  }
}
export { ProjectCreation };