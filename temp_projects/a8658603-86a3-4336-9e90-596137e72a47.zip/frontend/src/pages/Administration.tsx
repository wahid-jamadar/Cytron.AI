import { html, LitElement } from 'lit';
import { UserList } from '../components/UserList.tsx';
import { RoleList } from '../components/RoleList.tsx';
import { OrganizationList } from '../components/OrganizationList.tsx';
@LitElement()
class Administration extends LitElement {
  render() {
    return html`<h1>Administration</h1><${UserList} /><${RoleList} /><${OrganizationList} />`;
  }
}
export { Administration };