import { html, render } from 'lit';
import { App } from './App.tsx';
render(html`<${App} />`, document.getElementById('root'));