import { html, LitElement, property } from 'lit';
import { router } from './router.ts';
import { Dashboard } from './pages/Dashboard.tsx';
import { ProjectCreation } from './pages/ProjectCreation.tsx';
import { TaskManagement } from './pages/TaskManagement.tsx';
import { ChatSystem } from './pages/ChatSystem.tsx';
import { FileManagement } from './pages/FileManagement.tsx';
import { CodeGeneration } from './pages/CodeGeneration.tsx';
import { Administration } from './pages/Administration.tsx';
@LitElement()
class App extends LitElement {
  @property({ type: String }) route = '';
  render() {
    return html`<${router(this.route)} />`;
  }
}
export { App };