import { html, LitElement } from 'lit';
import { Dashboard } from './pages/Dashboard.tsx';
import { ProjectCreation } from './pages/ProjectCreation.tsx';
import { TaskManagement } from './pages/TaskManagement.tsx';
import { ChatSystem } from './pages/ChatSystem.tsx';
import { FileManagement } from './pages/FileManagement.tsx';
import { CodeGeneration } from './pages/CodeGeneration.tsx';
import { Administration } from './pages/Administration.tsx';
const routes = {
  '/dashboard': Dashboard,
  '/projects/create': ProjectCreation,
  '/tasks': TaskManagement,
  '/chat': ChatSystem,
  '/files': FileManagement,
  '/code': CodeGeneration,
  '/admin': Administration
};
export const router = (route) => routes[route];