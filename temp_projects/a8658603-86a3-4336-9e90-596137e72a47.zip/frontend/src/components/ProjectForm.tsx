import { html, LitElement } from 'lit';
@LitElement()
class ProjectForm extends LitElement {
  render() {
    return html`<h2>Project Form</h2>`;
  }
}
export { ProjectForm };