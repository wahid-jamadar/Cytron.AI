import { html, LitElement } from 'lit';
@LitElement()
class ProjectList extends LitElement {
  render() {
    return html`<h2>Project List</h2>`;
  }
}
export { ProjectList };