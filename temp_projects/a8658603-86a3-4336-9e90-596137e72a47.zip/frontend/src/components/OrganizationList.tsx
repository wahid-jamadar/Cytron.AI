import { html, LitElement } from 'lit';
@LitElement()
class OrganizationList extends LitElement {
  render() {
    return html`<h2>Organization List</h2>`;
  }
}
export { OrganizationList };