import { html, LitElement } from 'lit';
@LitElement()
class TaskList extends LitElement {
  render() {
    return html`<h2>Task List</h2>`;
  }
}
export { TaskList };