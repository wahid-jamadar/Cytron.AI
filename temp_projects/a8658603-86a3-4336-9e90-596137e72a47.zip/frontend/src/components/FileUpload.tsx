import { html, LitElement } from 'lit';
@LitElement()
class FileUpload extends LitElement {
  render() {
    return html`<h2>File Upload</h2>`;
  }
}
export { FileUpload };