import { html, LitElement } from 'lit';
@LitElement()
class ChatWindow extends LitElement {
  render() {
    return html`<h2>Chat Window</h2>`;
  }
}
export { ChatWindow };