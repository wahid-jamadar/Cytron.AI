import { html, LitElement } from 'lit';
@LitElement()
class TaskForm extends LitElement {
  render() {
    return html`<h2>Task Form</h2>`;
  }
}
export { TaskForm };