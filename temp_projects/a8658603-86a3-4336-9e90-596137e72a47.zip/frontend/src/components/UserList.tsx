import { html, LitElement } from 'lit';
@LitElement()
class UserList extends LitElement {
  render() {
    return html`<h2>User List</h2>`;
  }
}
export { UserList };