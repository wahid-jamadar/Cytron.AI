import { html, LitElement } from 'lit';
@LitElement()
class CodeEditor extends LitElement {
  render() {
    return html`<h2>Code Editor</h2>`;
  }
}
export { CodeEditor };