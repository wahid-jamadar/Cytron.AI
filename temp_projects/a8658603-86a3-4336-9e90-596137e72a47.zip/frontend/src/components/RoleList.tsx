import { html, LitElement } from 'lit';
@LitElement()
class RoleList extends LitElement {
  render() {
    return html`<h2>Role List</h2>`;
  }
}
export { RoleList };