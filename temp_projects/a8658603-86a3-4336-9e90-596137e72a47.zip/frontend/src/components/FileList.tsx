import { html, LitElement } from 'lit';
@LitElement()
class FileList extends LitElement {
  render() {
    return html`<h2>File List</h2>`;
  }
}
export { FileList };