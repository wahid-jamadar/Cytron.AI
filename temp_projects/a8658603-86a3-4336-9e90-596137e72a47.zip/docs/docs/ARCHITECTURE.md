# Architecture Overview
## High-Level Architecture
The application consists of the following components:
* Frontend: A React application that provides the user interface
* Backend: A FastAPI application that provides the API endpoints
* Database: A PostgreSQL database that stores the application data

## Sequence Diagram