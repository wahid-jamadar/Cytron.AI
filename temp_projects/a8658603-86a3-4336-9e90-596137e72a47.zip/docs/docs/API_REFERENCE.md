# API Reference
## Project Endpoints
### Create Project
* Method: `POST`
* Path: `/api/v1/projects`
* Description: Create a new project
* Request Body: `{"name": "string", "description": "string"}`
* Response Schema: `{"id": "integer", "name": "string", "description": "string"}`
* Auth Required: `true`
* Example Curl: `curl -X POST -H "Content-Type: application/json" -d '{"name": "My Project", "description": "This is my project"}' http://localhost:3000/api/v1/projects`

### Get Projects
* Method: `GET`
* Path: `/api/v1/projects`
* Description: Get a list of projects
* Request Body: `null`
* Response Schema: `[{"id": "integer", "name": "string", "description": "string"}]`
* Auth Required: `true`
* Example Curl: `curl -X GET http://localhost:3000/api/v1/projects`

## Task Endpoints
### Create Task
* Method: `POST`
* Path: `/api/v1/tasks`
* Description: Create a new task
* Request Body: `{"name": "string", "description": "string", "project_id": "integer"}`
* Response Schema: `{"id": "integer", "name": "string", "description": "string", "project_id": "integer"}`
* Auth Required: `true`
* Example Curl: `curl -X POST -H "Content-Type: application/json" -d '{"name": "My Task", "description": "This is my task", "project_id": 1}' http://localhost:3000/api/v1/tasks`

### Get Tasks
* Method: `GET`
* Path: `/api/v1/tasks`
* Description: Get a list of tasks
* Request Body: `null`
* Response Schema: `[{"id": "integer", "name": "string", "description": "string", "project_id": "integer"}]`
* Auth Required: `true`
* Example Curl: `curl -X GET http://localhost:3000/api/v1/tasks`

## Chat Endpoints
### Send Message
* Method: `POST`
* Path: `/api/v1/chat`
* Description: Send a message
* Request Body: `{"message": "string", "user_id": "integer"}`
* Response Schema: `{"id": "integer", "message": "string", "user_id": "integer"}`
* Auth Required: `true`
* Example Curl: `curl -X POST -H "Content-Type: application/json" -d '{"message": "Hello", "user_id": 1}' http://localhost:3000/api/v1/chat`

### Get Messages
* Method: `GET`
* Path: `/api/v1/chat`
* Description: Get a list of messages
* Request Body: `null`
* Response Schema: `[{"id": "integer", "message": "string", "user_id": "integer"}]`
* Auth Required: `true`
* Example Curl: `curl -X GET http://localhost:3000/api/v1/chat`