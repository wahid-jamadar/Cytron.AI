# Setup Guide
## Prerequisites
* Docker
* Node.js
* Python

## Step-by-Step Setup
1. Clone the repository: `git clone https://github.com/your-repo/ai_project_manager.git`
2. Create a new file named `.env` in the root directory and add the following environment variables:
* `DB_HOST`: The hostname of the PostgreSQL database
* `DB_PORT`: The port number of the PostgreSQL database
* `DB_USERNAME`: The username to use for the PostgreSQL database
* `DB_PASSWORD`: The password to use for the PostgreSQL database
* `DB_NAME`: The name of the PostgreSQL database
3. Run `docker-compose up` to start the application

## Running Tests Locally
1. Run `docker-compose run --rm backend pytest` to run the backend tests
2. Run `docker-compose run --rm frontend vitest` to run the frontend tests